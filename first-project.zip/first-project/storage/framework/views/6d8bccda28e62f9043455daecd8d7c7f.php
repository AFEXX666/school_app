<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-lg-8 margin-tb">
            <div class="row">
                <div class="col-md-12">
                    <div class="mt-5">
                        <h2>Show</h2>
                    </div>
                </div>
                <div class="col-md-12 text-end mt-4">
                    <a class="btn btn-primary" href="<?php echo e(route('groups.index')); ?>">Back</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row justify-content-center mt-5">
        <div class="col-lg-8 margin-tb">
            <table class="table table-bordered mt-4">
                <tr>
                    <th>No</th>
                    <th>Group</th>
                    <th>Grade</th>
                    <th>Academic Level</th>
                </tr>
                <tr>
                    <td><?php echo e($group->id); ?></td>
                    <td><?php echo e($group->group); ?></td>
                    <td><?php echo e($group->grade); ?></td>
                    <td><?php echo e($group->academicLvl); ?></td>
                </tr>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('groups.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\first-project\resources\views/groups/show.blade.php ENDPATH**/ ?>