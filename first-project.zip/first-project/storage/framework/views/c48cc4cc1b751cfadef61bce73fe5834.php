<?php $__env->startSection('content'); ?>
    <div class="row justify content-center">
        <div class="col-lg-8 margin-tb">
            <div class="row">
                <div class="col-md-12">
                    <div class="text-center mt-5">
                        <h2>Laravel Student List</h2>
                    </div>
                </div>
                <div class="col-md-12 text-start mt-4">
                    <a href="<?php echo e(route('students.create')); ?>" class="btn btn-primary">+ Create new Student</a>
                    <a href="<?php echo e(url('/teachers')); ?>" class="btn btn-primary">Teachers</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-lg-8 margin-tb">
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success mt-3">
                    <span><?php echo e($message); ?></span>
                </div>
            <?php endif; ?>
            <table class="table table-bordered mt-4">
                <tr>
                    <th>No</th>
                    <th>Name</th>
                    <th>Lastname</th>
                    <th>Address</th>
                    <th>Group</th>
                    <th>Options</th>
                </tr>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($student->id); ?></td>
                        <td><?php echo e($student->name); ?></td>
                        <td><?php echo e($student->lastname); ?></td>
                        <td><?php echo e($student->address); ?></td>
                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($student->group_id == $group->id): ?>
                                <td><?php echo e($group->group); ?>-<?php echo e($group->grade); ?></td>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td>
                            <form action="<?php echo e(route('students.destroy', $student->id)); ?>" method="post">
                                <a class="btn btn-info btn-sm text-white" href="<?php echo e(route('students.show', $student->id)); ?>">Show</a>
                                <a class="btn btn-primary btn-sm" href="<?php echo e(route('students.edit', $student->id)); ?>">Edit</a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\first-project\resources\views/students/index.blade.php ENDPATH**/ ?>