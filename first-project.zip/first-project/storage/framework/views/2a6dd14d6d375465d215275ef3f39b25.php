<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-lg-8 margin-tb">
            <div class="row">
                <div class="col-md-12">
                    <div class="mt-5">
                        <h2>Show</h2>
                    </div>
                </div>
                <div class="col-md-12 text-end mt-4">
                    <a class="btn btn-primary" href="<?php echo e(route('teachers.index')); ?>">Back</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row justify-content-center mt-5">
        <div class="col-lg-8 margin-tb">
            <table class="table table-bordered mt-4">
                <tr>
                    <th>No</th>
                    <th>Name</th>
                    <th>LastName</th>
                    <th>Career</th>
                </tr>
                <tr>
                    <td><?php echo e($teacher->id); ?></td>
                    <td><?php echo e($teacher->name); ?></td>
                    <td><?php echo e($teacher->lastname); ?></td>
                    <td><?php echo e($teacher->career); ?></td>
                </tr>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('teachers.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cuell\Desktop\first-project\resources\views/teachers/show.blade.php ENDPATH**/ ?>