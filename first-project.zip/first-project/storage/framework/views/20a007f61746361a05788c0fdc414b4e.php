<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-lg-8 margin-tb">
            <div class="row">
                <div class="col-md-12">
                    <div class="mt-5">
                        <h2>Show</h2>
                    </div>
                </div>
                <div class="col-md-12 text-end mt-4">
                    <a class="btn btn-primary" href="<?php echo e(route('subjects.index')); ?>">Back</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row justify-content-center mt-5">
        <div class="col-lg-8 margin-tb">
            <table class="table table-bordered mt-4">
                <tr>
                    <th>No</th>
                    <th>Name</th>
                    <th>Objective</th>
                    <th>Description</th>
                </tr>
                <tr>
                    <td><?php echo e($subject->id); ?></td>
                    <td><?php echo e($subject->name); ?></td>
                    <td><?php echo e($subject->objective); ?></td>
                    <td><?php echo e($subject->description); ?></td>
                </tr>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('subjects.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cuell\Desktop\first-project\resources\views/subjects/show.blade.php ENDPATH**/ ?>