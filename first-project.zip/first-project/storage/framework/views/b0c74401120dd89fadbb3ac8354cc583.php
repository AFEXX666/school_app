<?php $__env->startSection('content'); ?>

    <div class="row justify content-center">
        <div class="col-lg-8 margin-tb">
            <div class="row">
                <div class="col-md-12">
                    <div class="text-center mt-5">
                        <h2>Laravel Student List</h2>
                    </div>
                </div>
                <div class="col-md-12 text-end mt-4">
                    <a href="<?php echo e(route('students.create')); ?>" class="btn btn-primary">+ Create new Student</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-lg-8 margin-tb">
            <?php if($message = Session::get('success')): ?>
            <div class="alertalert-success mt-3"></div>
            <span><?php echo e($message); ?></span>
            <?php endif; ?>
            <table class="table table-bordered mt-4">
                <tr>
                    <td>No</td>
                    <td>Name</td>
                    <td>LastName</td>
                    <td>Address</td>
                </tr>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($student->id); ?></td>
                        <td><?php echo e($student->name); ?></td>
                        <td><?php echo e($student->lastname); ?></td>
                        <td><?php echo e($student->address); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/students/index.blade.php ENDPATH**/ ?>