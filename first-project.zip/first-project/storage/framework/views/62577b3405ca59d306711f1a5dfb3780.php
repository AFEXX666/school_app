<?php $__env->startSection('content'); ?>
    <div class="row justify content-center">
        <div class="col-lg-8 margin-tb">
            <div class="row">
                <div class="col-md-12">
                    <div class="text-center mt-5">
                        <h2>Laravel Group List</h2>
                    </div>
                </div>
                <div class="col-md-12 text-end mt-4">
                    <a href="<?php echo e(route('groups.create')); ?>" class="btn btn-primary">+ Create new Group</a>
                    <a href="<?php echo e(url('/teachers')); ?>" class="btn btn-primary">Teachers</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-lg-8 margin-tb">
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success mt-3">
                    <span><?php echo e($message); ?></span>
                </div>
            <?php endif; ?>
            <table class="table table-bordered mt-4">
                <tr>
                    <th>No</th>
                    <th>Group</th>
                    <th>Grade</th>
                    <th>Academic Level</th>
                    <th>Options</th>
                </tr>
                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($group->id); ?></td>
                        <td><?php echo e($group->group); ?></td>
                        <td><?php echo e($group->grade); ?></td>
                        <td><?php echo e($group->academicLvl); ?></td>
                        <td>
                            <form action="<?php echo e(route('groups.destroy', $group->id)); ?>" method="post">
                                <a class="btn btn-info btn-sm text-white" href="<?php echo e(route('groups.show', $group->id)); ?>">Show</a>
                                <a class="btn btn-primary btn-sm" href="<?php echo e(route('groups.edit', $group->id)); ?>">Edit</a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('groups.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\first-project\resources\views/groups/index.blade.php ENDPATH**/ ?>