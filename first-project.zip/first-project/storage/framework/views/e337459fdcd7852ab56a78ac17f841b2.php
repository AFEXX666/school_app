<?php $__env->startSection('content'); ?>
    <div class="row justify content-center">
        <div class="col-lg-8 margin-tb">
            <div class="row">
                <div class="col-md-12">
                    <div class="text-center mt-5">
                        <h2>Laravel Teacher List</h2>
                    </div>
                </div>
                <div class="col-md-12 text-end mt-4">
                    <a href="<?php echo e(route('teachers.create')); ?>" class="btn btn-primary">+ Create new Teacher</a>
                    <a href="<?php echo e(url('/students')); ?>" class="btn btn-primary">Students</a>
                    <a href="<?php echo e(url('/groups')); ?>" class="btn btn-primary">Groups</a>
                    <a href="<?php echo e(url('/subjects')); ?>" class="btn btn-primary">Subjects</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-lg-8 margin-tb">
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success mt-3">
                    <span><?php echo e($message); ?></span>
                </div>
            <?php endif; ?>
            <table class="table table-bordered mt-4">
                <tr>
                    <th>No</th>
                    <th>Name</th>
                    <th>Lastname</th>
                    <th>Career</th>
                    <th>Options</th>
                </tr>
                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($teacher->id); ?></td>
                        <td><?php echo e($teacher->name); ?></td>
                        <td><?php echo e($teacher->lastname); ?></td>
                        <td><?php echo e($teacher->career); ?></td>
                        <td>
                            <form action="<?php echo e(route('teachers.destroy', $teacher->id)); ?>" method="post">
                                <a class="btn btn-info btn-sm text-white" href="<?php echo e(route('teachers.show', $teacher->id)); ?>">Show</a>
                                <a class="btn btn-primary btn-sm" href="<?php echo e(route('teachers.edit', $teacher->id)); ?>">Edit</a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('teachers.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\first-project\resources\views/teachers/index.blade.php ENDPATH**/ ?>